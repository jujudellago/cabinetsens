<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_carousel/carousel.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_carousel/functions.php';
