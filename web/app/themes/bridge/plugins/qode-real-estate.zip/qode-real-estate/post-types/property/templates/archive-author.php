<?php
get_header();

qodef_re_get_author_page_property();

get_footer();