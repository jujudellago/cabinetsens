<?php

include_once 'admin/options/compare-map.php';
include_once 'functions.php';