<article class="qodef-package-item <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>">
    <div class="qodef-package-item-inner">
        <?php echo qodef_re_get_cpt_shortcode_module_template_part( 'package', 'package-list', 'layout-collections/' . $item_layout, '', $params, $additional_params ); ?>
    </div>
</article>