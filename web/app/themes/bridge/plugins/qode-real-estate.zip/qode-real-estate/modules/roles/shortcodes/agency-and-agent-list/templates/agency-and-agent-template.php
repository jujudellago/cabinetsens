<div class="qodef-agency-agent-list <?php echo esc_attr($holder_classes);?>">
	<ul class="qodef-aal-inner <?php echo esc_attr($holder_inner_classes);?>">
		<?php echo qodef_re_get_module_template_part( 'roles/shortcodes/agency-and-agent-list/templates/user-template', '', $params);?>
	</ul>
</div>