<?php 
/**
 * The template for displaying page content
 *
 * @since 1.0.0
 */

get_header(); ?>

	<?php get_template_part( 'template-parts/content-page' ); ?>

<?php get_footer(); ?>