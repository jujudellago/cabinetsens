<?php
/**
 * A blank template file that can be overridden in a theme
 *
 * @since 1.0.0
 */